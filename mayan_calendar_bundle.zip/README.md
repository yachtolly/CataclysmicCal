# 🌒 Mayan Calendar + Cataclysm Countdown

A fully self-contained HTML project that lets you explore the Mayan calendar, cycles, and theorized cataclysms.